# Lexis Offline Edition

Edição **local** do LexisPredict (mesma base de código), **sem Vercel e sem Supabase** por enquanto.

## Ideia

Como um LLM local: você sobe o app no PC, carrega a carteira (CSV/planilha) e opera.

| Online (SaaS) | Offline Edition |
|---------------|-----------------|
| Supabase | `data/lexis-offline-db.json` |
| Auth nuvem | Operador local automático |
| Vercel | `next dev` / `next start` no PC |
| DataJud/DJEN | Opcional depois (ainda não obrigatório) |

## Subir

```bash
cp .env.offline.example .env.local
npm install
npm run offline:dev
```

Abra: http://127.0.0.1:9002/offline-setup

1. Importar CSV (export do Lexis ou planilha com Protocolo/Cliente)
2. Ir em **Carteira** (`/cases`), **Processos**, **Tarefas**

## Desktop (Electron)

```bash
# terminal 1 — na raiz do LexisPredict
npm run offline:build
npm run offline:start

# terminal 2
cd desktop-offline
npm install
npm start
```

O Electron aponta para o Next local. Empacotar `.exe`: `npm run dist` dentro de `desktop-offline` (depois do build do Next).

## Arquivos novos

- `src/lib/offline/*` — modo, DB JSON, import CSV
- `src/app/actions/offline-actions.ts`
- `src/app/offline-setup/page.tsx`
- `desktop-offline/` — shell Electron
- patches em `server-db.ts`, `middleware.ts`, `auth-provider.tsx`

## Limites honestos (v0.1)

- Carteira / listagens / KPI básico a partir do JSON local
- Scanners tribunal, WhatsApp Evolution, multi-empresa: **não** são o foco desta edição ainda
- IA: só se você configurar chaves depois; o app sobe sem elas

## Próximos passos naturais

1. SQLite no lugar do JSON (volume grande)
2. Stub de DataJud/DJEN com cache em arquivo
3. electron-builder incluindo o `.next` standalone

