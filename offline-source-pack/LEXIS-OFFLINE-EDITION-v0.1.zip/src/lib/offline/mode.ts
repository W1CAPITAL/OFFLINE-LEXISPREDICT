/**
 * Lexis Offline Edition — flag única.
 * Server: LEXIS_OFFLINE=1
 * Client: NEXT_PUBLIC_LEXIS_OFFLINE=1
 */
export function isLexisOffline(): boolean {
  if (typeof process !== 'undefined') {
    const a = String(process.env.LEXIS_OFFLINE || '').trim().toLowerCase();
    const b = String(process.env.NEXT_PUBLIC_LEXIS_OFFLINE || '').trim().toLowerCase();
    if (a === '1' || a === 'true' || a === 'yes') return true;
    if (b === '1' || b === 'true' || b === 'yes') return true;
  }
  return false;
}

/** Empresa / usuário fixos do modo offline (single-tenant local). */
export const OFFLINE_EMPRESA_ID = '00000000-0000-4000-8000-000000000001';
export const OFFLINE_AUTH_ID = '00000000-0000-4000-8000-0000000000aa';
export const OFFLINE_USER_ID = '00000000-0000-4000-8000-0000000000bb';
export const OFFLINE_EMAIL = 'offline@lexis.local';
export const OFFLINE_NOME = 'Operador Local';
