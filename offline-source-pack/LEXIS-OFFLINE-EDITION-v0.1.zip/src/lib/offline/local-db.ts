/**
 * Banco local da Offline Edition.
 * Arquivo: data/lexis-offline-db.json (ao lado do processo Node / Electron).
 */
import { promises as fs } from 'fs';
import path from 'path';
import {
  OFFLINE_AUTH_ID,
  OFFLINE_EMAIL,
  OFFLINE_EMPRESA_ID,
  OFFLINE_NOME,
  OFFLINE_USER_ID,
} from './mode';

export type OfflineDb = {
  version: number;
  empresa_id: string;
  updated_at: string;
  cases: any[];
  notes: any[];
  meta: {
    sourceName?: string | null;
    importedAt?: string | null;
    label?: string;
  };
};

const DEFAULT_DB = (): OfflineDb => ({
  version: 1,
  empresa_id: OFFLINE_EMPRESA_ID,
  updated_at: new Date().toISOString(),
  cases: [],
  notes: [],
  meta: { sourceName: null, importedAt: null, label: 'vazio' },
});

function resolveDbPath(): string {
  if (process.env.LEXIS_OFFLINE_DB) return process.env.LEXIS_OFFLINE_DB;
  // cwd do next / electron
  return path.join(process.cwd(), 'data', 'lexis-offline-db.json');
}

let cache: OfflineDb | null = null;
let writeQueue: Promise<void> = Promise.resolve();

export async function readOfflineDb(): Promise<OfflineDb> {
  if (cache) return cache;
  const file = resolveDbPath();
  try {
    const raw = await fs.readFile(file, 'utf8');
    const parsed = JSON.parse(raw) as OfflineDb;
    if (!parsed || !Array.isArray(parsed.cases)) {
      cache = DEFAULT_DB();
    } else {
      cache = {
        ...DEFAULT_DB(),
        ...parsed,
        cases: parsed.cases || [],
        notes: parsed.notes || [],
      };
    }
  } catch {
    cache = DEFAULT_DB();
  }
  return cache!;
}

export async function writeOfflineDb(db: OfflineDb): Promise<void> {
  const file = resolveDbPath();
  const dir = path.dirname(file);
  await fs.mkdir(dir, { recursive: true });
  const next: OfflineDb = {
    ...db,
    version: 1,
    empresa_id: OFFLINE_EMPRESA_ID,
    updated_at: new Date().toISOString(),
  };
  cache = next;
  writeQueue = writeQueue.then(async () => {
    const tmp = file + '.tmp';
    await fs.writeFile(tmp, JSON.stringify(next), 'utf8');
    await fs.rename(tmp, file);
  });
  await writeQueue;
}

export async function getOfflineCases(): Promise<any[]> {
  const db = await readOfflineDb();
  return db.cases || [];
}

export async function saveOfflineCases(cases: any[]): Promise<void> {
  const db = await readOfflineDb();
  db.cases = cases;
  await writeOfflineDb(db);
}

export async function getOfflineNotes(): Promise<any[]> {
  const db = await readOfflineDb();
  return db.notes || [];
}

export async function saveOfflineNotes(notes: any[]): Promise<void> {
  const db = await readOfflineDb();
  db.notes = notes;
  await writeOfflineDb(db);
}

export function offlineUserContext() {
  return {
    auth_id: OFFLINE_AUTH_ID,
    empresa_id: OFFLINE_EMPRESA_ID,
    cargo: 'Superadmin' as const,
    email: OFFLINE_EMAIL,
    isSuperAdmin: true,
    isSupervisor: true,
    isViewer: false,
    isMasterView: true,
    isAdministrador: true,
    isEmpresaWide: true,
    weight: 100,
    nome: OFFLINE_NOME,
    user_id: OFFLINE_USER_ID,
  };
}

export async function setOfflineMeta(meta: OfflineDb['meta']) {
  const db = await readOfflineDb();
  db.meta = { ...db.meta, ...meta };
  await writeOfflineDb(db);
}

export async function getOfflineMeta() {
  const db = await readOfflineDb();
  return db.meta;
}
