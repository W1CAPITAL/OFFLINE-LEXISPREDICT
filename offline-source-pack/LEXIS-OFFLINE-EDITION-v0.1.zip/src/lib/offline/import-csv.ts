/**
 * Importa CSV/planilha para casos da Offline Edition.
 */
export type ImportResult = { ok: boolean; count: number; message: string };

function norm(h: string) {
  return String(h || '')
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let cur: string[] = [];
  let cell = '';
  let inQ = false;
  const s = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (inQ) {
      if (ch === '"') {
        if (s[i + 1] === '"') {
          cell += '"';
          i++;
        } else inQ = false;
      } else cell += ch;
    } else if (ch === '"') inQ = true;
    else if (ch === ',') {
      cur.push(cell);
      cell = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && s[i + 1] === '\n') i++;
      cur.push(cell);
      cell = '';
      if (cur.some((c) => c.trim())) rows.push(cur);
      cur = [];
    } else cell += ch;
  }
  cur.push(cell);
  if (cur.some((c) => c.trim())) rows.push(cur);
  return rows;
}

function mapHeaders(headers: string[]) {
  const idx: Record<string, number> = {};
  headers.forEach((h, i) => {
    const n = norm(h);
    if (idx.protocolo == null && /protocolo|cnj|processo|numero/.test(n)) idx.protocolo = i;
    else if (idx.cliente == null && /cliente|nome|parte/.test(n)) idx.cliente = i;
    else if (idx.telefone == null && /telefone|celular|whatsapp|fone/.test(n)) idx.telefone = i;
    else if (idx.tribunal == null && /tribunal|tj/.test(n)) idx.tribunal = i;
    else if (idx.status == null && /status|situacao|situação/.test(n)) idx.status = i;
    else if (idx.escritorio == null && /escritorio|escritório|banca/.test(n)) idx.escritorio = i;
    else if (idx.advogado == null && /advogado|oab/.test(n)) idx.advogado = i;
    else if (idx.ultimo == null && /ultimo|último|retorno|atend/.test(n)) idx.ultimo = i;
    else if (idx.prazo == null && /prazo|proximo|próximo/.test(n)) idx.prazo = i;
    else if (idx.obs == null && /obs|nota|observ/.test(n)) idx.obs = i;
  });
  return idx;
}

function cell(row: string[], i?: number) {
  if (i == null || i < 0) return '';
  return String(row[i] ?? '').trim();
}

export function csvTextToCases(text: string, sourceName?: string): ImportResult & { cases: any[] } {
  const matrix = parseCsv(text);
  if (matrix.length < 2) {
    return { ok: false, count: 0, message: 'CSV vazio ou sem cabeçalho', cases: [] };
  }
  const headers = matrix[0];
  const idx = mapHeaders(headers);
  if (idx.protocolo == null && idx.cliente == null) {
    return {
      ok: false,
      count: 0,
      message: 'Cabeçalho precisa de Protocolo/CNJ ou Cliente',
      cases: [],
    };
  }

  const cases: any[] = [];
  const seen = new Set<string>();
  for (let r = 1; r < matrix.length; r++) {
    const row = matrix[r];
    const protocolo = cell(row, idx.protocolo);
    const cliente = cell(row, idx.cliente) || '—';
    const dig = protocolo.replace(/\D/g, '');
    const key = dig || `row_${r}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const status = cell(row, idx.status) || 'EM ANDAMENTO';
    const id = dig ? `off_${dig}` : `off_${r}_${Date.now()}`;
    cases.push({
      id,
      protocolo: protocolo || key,
      cliente,
      telefone: cell(row, idx.telefone),
      tribunal: cell(row, idx.tribunal),
      status,
      situacao: status,
      escritorio: cell(row, idx.escritorio),
      advogado: cell(row, idx.advogado),
      ultimoRetorno: cell(row, idx.ultimo),
      proximoPrazo: cell(row, idx.prazo),
      observacoes: cell(row, idx.obs),
      empresa_id: '00000000-0000-4000-8000-000000000001',
      offline: true,
      sourceName: sourceName || 'csv',
    });
  }

  return {
    ok: true,
    count: cases.length,
    message: `Importados ${cases.length} processos`,
    cases,
  };
}
