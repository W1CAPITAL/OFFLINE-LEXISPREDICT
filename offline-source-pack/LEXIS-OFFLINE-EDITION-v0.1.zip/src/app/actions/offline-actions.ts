'use server';

import { isLexisOffline } from '@/lib/offline/mode';
import {
  getOfflineCases,
  getOfflineMeta,
  saveOfflineCases,
  setOfflineMeta,
} from '@/lib/offline/local-db';
import { csvTextToCases } from '@/lib/offline/import-csv';

export async function offlineImportCsvAction(text: string, sourceName?: string) {
  if (!isLexisOffline()) {
    return { success: false, error: 'Só disponível na Offline Edition (LEXIS_OFFLINE=1)' };
  }
  const r = csvTextToCases(text, sourceName);
  if (!r.ok) return { success: false, error: r.message, count: 0 };
  await saveOfflineCases(r.cases);
  await setOfflineMeta({
    sourceName: sourceName || 'csv',
    importedAt: new Date().toISOString(),
    label: r.message,
  });
  return { success: true, count: r.count, message: r.message };
}

export async function offlineStatusAction() {
  if (!isLexisOffline()) {
    return { offline: false as const };
  }
  const cases = await getOfflineCases();
  const meta = await getOfflineMeta();
  return {
    offline: true as const,
    count: cases.length,
    meta,
  };
}

export async function offlineClearAction() {
  if (!isLexisOffline()) return { success: false };
  await saveOfflineCases([]);
  await setOfflineMeta({ sourceName: null, importedAt: null, label: 'limpo' });
  return { success: true };
}
