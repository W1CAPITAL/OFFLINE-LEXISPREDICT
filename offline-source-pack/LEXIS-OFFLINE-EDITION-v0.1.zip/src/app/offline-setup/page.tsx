"use client";

/**
 * Lexis Offline Edition — importar planilha / ver status da base local.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  offlineClearAction,
  offlineImportCsvAction,
  offlineStatusAction,
} from "@/app/actions/offline-actions";
import { HardDrive, Upload, Trash2, Loader2, RefreshCw } from "lucide-react";
import Link from "next/link";

export default function OfflineSetupPage() {
  const { toast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<{
    offline: boolean;
    count?: number;
    meta?: any;
  } | null>(null);

  const refresh = useCallback(async () => {
    const s = await offlineStatusAction();
    setStatus(s as any);
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const onFile = async (file: File) => {
    setLoading(true);
    try {
      const text = await file.text();
      const r = await offlineImportCsvAction(text, file.name);
      if (!r.success) {
        toast({ title: "Falha no import", description: r.error, variant: "destructive" });
      } else {
        toast({ title: "Importado", description: r.message || `${r.count} processos` });
        await refresh();
      }
    } catch (e: any) {
      toast({ title: "Erro", description: e?.message || String(e), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const clear = async () => {
    if (!confirm("Apagar toda a carteira local?")) return;
    await offlineClearAction();
    await refresh();
    toast({ title: "Base local limpa" });
  };

  const isOff = status?.offline === true;

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-black tracking-tight flex items-center gap-2">
              <HardDrive className="h-5 w-5 text-primary" />
              Offline Edition
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Mesma base LexisPredict · dados no PC · sem Vercel / Supabase
            </p>
          </div>
          <Badge variant={isOff ? "default" : "destructive"}>
            {isOff ? "MODO OFFLINE ATIVO" : "MODO ONLINE (nuvem)"}
          </Badge>
        </div>

        {!isOff && (
          <div className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-4 text-sm">
            Defina <code className="text-xs">LEXIS_OFFLINE=1</code> e{" "}
            <code className="text-xs">NEXT_PUBLIC_LEXIS_OFFLINE=1</code> no{" "}
            <code className="text-xs">.env.local</code> e reinicie o servidor.
          </div>
        )}

        <div className="grid gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-border p-4 bg-card">
            <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              Processos na base local
            </p>
            <p className="text-3xl font-black tabular-nums mt-1">{status?.count ?? "—"}</p>
          </div>
          <div className="rounded-xl border border-border p-4 bg-card sm:col-span-2">
            <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              Fonte
            </p>
            <p className="text-sm font-medium mt-1">
              {status?.meta?.sourceName || "—"} · {status?.meta?.label || "sem import"}
            </p>
            <p className="text-[11px] text-muted-foreground mt-1">
              {status?.meta?.importedAt
                ? new Date(status.meta.importedAt).toLocaleString("pt-BR")
                : ""}
            </p>
          </div>
        </div>

        <div className="rounded-xl border border-border p-5 bg-card space-y-4">
          <h2 className="text-sm font-black uppercase tracking-widest">1 · Carregar carteira</h2>
          <p className="text-sm text-muted-foreground">
            Importe um CSV exportado do Lexis (ou planilha com Protocolo / Cliente). Isso vira a
            carteira local — depois use Carteira, Processos e Tarefas normalmente.
          </p>
          <input
            ref={fileRef}
            type="file"
            accept=".csv,text/csv,text/plain"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void onFile(f);
              e.target.value = "";
            }}
          />
          <div className="flex flex-wrap gap-2">
            <Button
              disabled={loading || !isOff}
              onClick={() => fileRef.current?.click()}
              className="font-black uppercase text-[10px] tracking-widest"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Upload className="h-4 w-4 mr-2" />
              )}
              Importar CSV
            </Button>
            <Button type="button" variant="secondary" onClick={() => void refresh()}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Atualizar status
            </Button>
            <Button type="button" variant="destructive" onClick={() => void clear()} disabled={!isOff}>
              <Trash2 className="h-4 w-4 mr-2" />
              Limpar base
            </Button>
            <Button type="button" variant="outline" asChild>
              <Link href="/cases">Abrir carteira</Link>
            </Button>
          </div>
        </div>

        <div className="rounded-xl border border-border p-5 bg-muted/30 text-sm space-y-2">
          <h2 className="text-sm font-black uppercase tracking-widest">2 · Como rodar o EXE / local</h2>
          <ol className="list-decimal pl-5 space-y-1 text-muted-foreground">
            <li>
              Copie <code className="text-xs">.env.offline.example</code> →{" "}
              <code className="text-xs">.env.local</code>
            </li>
            <li>
              <code className="text-xs">npm install && npm run offline:dev</code>
            </li>
            <li>Importe o CSV nesta tela</li>
            <li>
              Desktop: pasta <code className="text-xs">desktop-offline/</code> (Electron sobe o Next
              local)
            </li>
          </ol>
        </div>
      </main>
    </div>
  );
}
