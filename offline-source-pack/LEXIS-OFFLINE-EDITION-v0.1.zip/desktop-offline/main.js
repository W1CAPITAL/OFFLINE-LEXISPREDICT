/**
 * Lexis Offline Desktop — sobe o Next local e abre na janela.
 * Pré-requisito: na raiz do LexisPredict:
 *   npm run offline:build && npm run offline:start
 * Ou este shell inicia `npm run offline:start` automaticamente.
 */
const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const http = require('http');

const PORT = process.env.LEXIS_PORT || 9002;
const ROOT = path.resolve(__dirname, '..');
let mainWindow = null;
let child = null;

function waitForServer(maxMs = 120000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const tick = () => {
      const req = http.get(`http://127.0.0.1:${PORT}`, (res) => {
        res.resume();
        resolve(true);
      });
      req.on('error', () => {
        if (Date.now() - start > maxMs) reject(new Error('Timeout aguardando Next'));
        else setTimeout(tick, 800);
      });
    };
    tick();
  });
}

function startNext() {
  const env = {
    ...process.env,
    LEXIS_OFFLINE: '1',
    NEXT_PUBLIC_LEXIS_OFFLINE: '1',
    PORT: String(PORT),
  };
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  child = spawn(npm, ['run', 'offline:start'], {
    cwd: ROOT,
    env,
    shell: true,
    stdio: 'inherit',
  });
  child.on('exit', (code) => {
    console.log('next exit', code);
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1480,
    height: 920,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#0b0b0c',
    title: 'Lexis Offline Edition',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  mainWindow.loadURL(`http://127.0.0.1:${PORT}/offline-setup`);
  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function buildMenu() {
  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      {
        label: 'Lexis Offline',
        submenu: [
          {
            label: 'Importar / Setup',
            click: () => mainWindow && mainWindow.loadURL(`http://127.0.0.1:${PORT}/offline-setup`),
          },
          {
            label: 'Carteira',
            click: () => mainWindow && mainWindow.loadURL(`http://127.0.0.1:${PORT}/cases`),
          },
          {
            label: 'Processos',
            click: () => mainWindow && mainWindow.loadURL(`http://127.0.0.1:${PORT}/processos`),
          },
          {
            label: 'Tarefas',
            click: () => mainWindow && mainWindow.loadURL(`http://127.0.0.1:${PORT}/tarefas`),
          },
          { type: 'separator' },
          { role: 'reload' },
          { role: 'quit' },
        ],
      },
      {
        label: 'Ajuda',
        submenu: [
          {
            label: 'Abrir pasta do projeto',
            click: () => shell.openPath(ROOT),
          },
        ],
      },
    ])
  );
}

app.whenReady().then(async () => {
  buildMenu();
  startNext();
  try {
    await waitForServer();
  } catch (e) {
    console.error(e);
  }
  createWindow();
});

app.on('window-all-closed', () => {
  if (child) {
    try {
      child.kill();
    } catch (_) {}
  }
  if (process.platform !== 'darwin') app.quit();
});
