// reservado para bridge futura (fs nativo / diálogos)
